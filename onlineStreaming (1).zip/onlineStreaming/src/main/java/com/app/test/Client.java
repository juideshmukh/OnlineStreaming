package com.app.test;

import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;

import com.app.dao.USerDao;
import com.app.factory.UserFactory;
import com.app.model.Package;
import com.app.model.User;
import com.app.util.HibernateUtil;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn=new Scanner(System.in);
		USerDao dao=UserFactory.getUser();
		String ch="";
		do {
			System.out.println("-----------Welcome To StreamingApp----------");
			System.out.println("Press 1: Register");
			System.out.println("Press 2: Login");
			System.out.println("  ");
			//System.out.println("1: to see your details");
			System.out.println("Packages");
			System.out.println("  ");
			
			System.out.println("Press 3: Display Users");
			System.out.println("Press 4: Display User on id");
			System.out.println("-------------------------------");
			System.out.println("Enter Your Choice:");
			int choice=sn.nextInt();
			switch (choice) {
			case 1:
				int i=dao.register();
				if(i==1) {
					System.out.println("Successfully Register");

				}else {
					System.out.println("Something went wrong...!");
				}
				break;
			case 2:
				User user=dao.login();
				if(user!=null &&user.getPassword().equals("user")){
					System.out.println("Welcome to User Portal..");
				}else {
					System.out.println("LOGED IN SUCCESSFULLY");
				}
				System.out.println("Select your choice :");
				//System.out.println("Press 1: to see your details");
				System.out.println("Press 1: Packages");
				int n =sn.nextInt();
/*
				if(n==1)
				{
					System.out.println("Enter your id to see your details:");
					int id=sn.nextInt();
					User u1=dao.findById(id);
					
					System.out.println(u1);
					break;
				}
				*/
				if(n==1)
				{

					
					/*query for package choices
					 * add in mysql  
					 * add this query in table user_subscription
					 * 
					 * insert into package values(1,"monthly",500);
					   insert into package values(2,"yearly",6000);
					  );
					  */


					System.out.println("select Packages : ");
					List<Package>allpackage=dao.listOfPackage(); 
					allpackage.stream().forEach(s->System.out.println(s.getPid()+"\t"+s.getPackage()+"\t"+s.getPrice()));
					System.out.println("please enter package id");

					System.out.println("enter 1 for Monthly package");
					System.out.println("enter 2 for Yearly package");
					System.out.println("press 1 for monthly package and pay 500rs");
					System.out.println("press 2 for yearly package and pay 6000rs");
					
					
					
					

					int pid=sn.nextInt();
					Package p=dao.findByID(pid);
					System.out.println(p);

					System.out.println("------------Make your Payment----------- ");
					System.out.println("Enter amount for your package :");
					Scanner a=new Scanner(System.in);
					int b=a.nextInt();
					if(pid==1)
					{
						if(b==500)
						{
							System.out.println("---------Payment Successfull----------");
							System.out.println("Entertainment");
							System.out.println("Movies ");
							System.out.println("Music ");
							System.out.println("Kids ");
							System.out.println("News ");
							System.out.println("-------------Happy Streaming------------");

						} else{
							System.out.println("Invalid Amount");
							System.out.println("--------Payment failed---------");

						}
					}

					else  if(pid==2)
					{


						if(b==6000)
						{
							System.out.println("---------Payment Successfull----------");
							System.out.println("Entertainment");
							System.out.println("Movies ");
							System.out.println("Music ");
							System.out.println("Kids ");
							System.out.println("News ");
							System.out.println("-------------Happy Streaming------------");



						}


						else{
							System.out.println("Invalid Amount");
							System.out.println("-------Payment failed------");    
						}

					}

					else {
						System.out.println("--------invalid choice---------");
					}}
				break;
			case 3:
				List<User>list=dao.listOfUsers();
				list.stream().forEach(new Consumer<User>() {
					public void accept(User s) {
						System.out.println(s.getId()+"\t"+s.getFisrtName()+" "+s.getLastName()+"\t"+s.getAddress()+"\t"+s.getMobile());
					}
				});
				break;
			case 4:
				System.out.println("Enter your id for find user:");
				int id=sn.nextInt();
				User u1=dao.findById(id);
				System.out.println(u1);
				break;
			default:
				System.out.println("Invalid Request...!");
				break;
			}
			System.out.println("Do you want to continue...(y)");
			ch=sn.next();
		}while(ch.equalsIgnoreCase("y"));
		System.out.println("Thank you");
	}

}


//SELECT user.id ,package.pid FROM 
//user INNER JOIN package ON user.id=package.pid;
