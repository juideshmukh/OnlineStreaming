package com.app.dto;

public class UserRequest {
private String uname;
private String password;

public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

@Override
public String toString() {
	return "UserRequest [uname=" + uname + ", password=" + password + "]";
}
public UserRequest(String uname, String password ) {
	super();
	this.uname = uname;
	this.password = password;
	 
}
public UserRequest() {
	super();
	// TODO Auto-generated constructor stub
}

}
