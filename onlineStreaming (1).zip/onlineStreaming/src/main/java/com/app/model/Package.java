package com.app.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Package {
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	
	private int pid;
	private String Package;
	private double Price;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPackage() {
		return Package;
	}
	public void setPackage(String package1) {
		Package = package1;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public  Package(int pid, String package1, double price) {
		super();
		this.pid = pid;
		Package = package1;
		Price = price;
	}
	public Package() {
		super();
	}
	@Override
	public String toString() {
		return "Package [pid=" + pid + ", Package=" + Package + ", Price=" + Price + "]";
	}
	 
	
	 


}
